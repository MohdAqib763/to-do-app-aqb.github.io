<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mx-auto p-8">

<a href="<?php echo e(url('/dashboard')); ?>" class="bg-black hover:bg-gray-900 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Back</a>
<br>
<?php if(session()->has('status')): ?>
    <div class="bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 mb-4" role="alert">
    <p class="font-bold">Success!</p>
        <p>    <?php echo e(session('status')); ?></p>
        </div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
    <div class="bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 mb-4" role="alert">
    <p class="font-bold">Error!</p>
    <p><?php echo e(session('error')); ?></p>
    </div>
    <?php endif; ?>
   
    <br>

    <form action="<?php echo e(url('save-tasks')); ?>" method="Post">
            <?php echo csrf_field(); ?>
            <div class="flex items-center  mb-4">
              
               
                <input type="hidden" name="employee_id" value="<?php echo e($id); ?>">
                <input required class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" name="employee_tasks" id="employee_tasks" type="text" placeholder="Add task here..">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit">Save</button>
           
              </div>
            
        </form>  
        <br>
<table id="myTable" class="table-auto w-full text-left p-4">
<caption class="caption-top">
    <?php echo e($data->name); ?> Tasks
  </caption>
  <thead>
    <tr>
      <th class="px-4 py-2">Id</th>
      <th class="px-4 py-2">To Do</th>
      <th class="px-4 py-2">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php if(!empty($tasks)): ?>

    <?php $i = 1; ?>
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td class="px-4 py-2"><?php echo e($i++); ?></td>
      <td class="px-4 py-2"><?php echo e($row->tasks_name); ?></td>
      <td class="px-4 py-2">
        <a href="<?php echo e(url('/edit-tasks',[$row->tasks_id])); ?>" class="bg-blue-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">Edit</a> 
        <a href="<?php echo e(url('/delete-tasks',[$row->tasks_id])); ?>"  class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Delete</a> 
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
   
  </tbody>
</table>

</div>

<script>
  let table = new DataTable('#myTable');
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\to-do-app\resources\views/add_task.blade.php ENDPATH**/ ?>