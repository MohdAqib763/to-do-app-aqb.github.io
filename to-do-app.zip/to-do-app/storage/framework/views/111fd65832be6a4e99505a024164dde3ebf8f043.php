<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container mx-auto p-8">
<?php if(session()->has('status')): ?>
    <div class="bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 mb-4" role="alert">
    <p class="font-bold">Success!</p>
        <p>    <?php echo e(session('status')); ?></p>
        </div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
    <div class="bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 mb-4" role="alert">
    <p class="font-bold">Error!</p>
    <p><?php echo e(session('error')); ?></p>
    </div>
    <?php endif; ?>

<table id="myTable" class="table-auto w-full text-left p-4">
<caption class="caption-top">
    Employees List
  </caption>
  <thead>
    <tr>
      <th class="px-4 py-2">Id</th>
      <th class="px-4 py-2">Name</th>
      <th class="px-4 py-2">Email</th>
      <th class="px-4 py-2">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td class="px-4 py-2"><?php echo e($row->id); ?></td>
      <td class="px-4 py-2"><?php echo e($row->name); ?></td>
      <td class="px-4 py-2"><?php echo e($row->email); ?></td>
      <td class="px-4 py-2">
        <a href="<?php echo e(url('/invite-employee',[$row->id])); ?>" class="bg-blue-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">Invite</a> 
        <a href="<?php echo e(url('/Add-tasks',[$row->id])); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Assign Tasks</a> 
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>
</table>

</div>
<script>
  let table = new DataTable('#myTable');
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\to-do-app\resources\views/dashboard.blade.php ENDPATH**/ ?>