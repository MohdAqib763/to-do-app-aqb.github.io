<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mx-auto p-8">

<a href="<?php echo e(url('/Add-tasks',[$emp->id])); ?>" class="bg-black hover:bg-gray-900 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Back</a>
<br>
<?php if(session()->has('status')): ?>
    <div class="bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 mb-4" role="alert">
    <p class="font-bold">Success!</p>
        <p>    <?php echo e(session('status')); ?></p>
        </div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
    <div class="bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 mb-4" role="alert">
    <p class="font-bold">Error!</p>
    <p><?php echo e(session('error')); ?></p>
    </div>
    <?php endif; ?>
   
    <br>

    <form action="<?php echo e(url('/update-task',)); ?>" method="Post">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="tasks">Edit Tasks</label>
                <input type="hidden" name="task_id" value="<?php echo e($tasks->tasks_id); ?>">
                <input required class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" name="employee_tasks" id="employee_tasks" type="text" value="<?php echo e($tasks->tasks_name); ?>">
            </div>
            
            <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit">Save</button>
        </form>  

</body>
</html><?php /**PATH C:\xampp\htdocs\to-do-app\resources\views/edit_task.blade.php ENDPATH**/ ?>